import { Injectable, computed, signal } from '@angular/core';
import { UserInfo } from '../../api/models';

export interface AuthState {
  accessToken: string | null;
  refreshToken: string | null;
  user: UserInfo | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

const INITIAL_STATE: AuthState = {
  accessToken: null,
  refreshToken: null,
  user: null,
  isAuthenticated: false,
  isLoading: false,
};

@Injectable({ providedIn: 'root' })
export class AuthStateService {
  private readonly _state = signal<AuthState>(INITIAL_STATE);

  // Selectors
  readonly state = this._state.asReadonly();
  readonly user = computed(() => this._state().user);
  readonly accessToken = computed(() => this._state().accessToken);
  readonly refreshToken = computed(() => this._state().refreshToken);
  readonly isAuthenticated = computed(() => this._state().isAuthenticated);
  readonly isLoading = computed(() => this._state().isLoading);
  readonly mustChangePassword = computed(() => this._state().user?.mustChangePassword ?? false);
  readonly tenantId = computed(() => this._state().user?.tenantId ?? null);
  readonly companyId = computed(() => this._state().user?.companyId ?? null);

  // Mutators
  setTokens(accessToken: string, refreshToken: string): void {
    this._state.update(s => ({ ...s, accessToken, refreshToken }));
  }

  setUser(user: UserInfo): void {
    this._state.update(s => ({ ...s, user, isAuthenticated: true }));
  }

  setLoading(isLoading: boolean): void {
    this._state.update(s => ({ ...s, isLoading }));
  }

  clearAuth(): void {
    this._state.set(INITIAL_STATE);
  }
}
